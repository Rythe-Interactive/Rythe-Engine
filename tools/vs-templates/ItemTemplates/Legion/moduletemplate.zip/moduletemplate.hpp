#pragma once
#include <core/core.hpp>

/**
 * @file $safeitemname$.hpp
 */

using namespace legion;

/**@class $safeitemname$
 * @brief Custom module.
 */
class $safeitemname$ final : public Module
{
public:
    /**@brief Will automatically be called once before the start of the application.
     */
    virtual void setup()
    {
        // Here you can report any custom components and systems.

        //reportComponent<component_type>();
        //reportSystem<SystemType>();
    }

    /**@brief This function is used to decide the order in which to call the setup function.
     */
    virtual priority_type priority() override
    {
        return default_priority;
    }
};
