#pragma once
#include <core/core.hpp>

/**
 * @file $safeitemname$.hpp
 */

using namespace legion;

/**@struct $safeitemname$
 * @brief Custom component.
 */
struct $safeitemname$ final
{
    // Components are recommended to only hold data and to have all data be public.
    // The smaller the component the faster it will be to work with.
};
