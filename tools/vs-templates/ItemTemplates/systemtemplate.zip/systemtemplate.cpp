#include "$safeitemname$.hpp"

void $safeitemname$::setup()
{
    // Register update() as a process.
    createProcess<&$safeitemname$::update>("Update");
}

void $safeitemname$::update(time::span deltaTime)
{
    // This will be called every frame during "Update".

    //static auto filter = createFilter<component0, component1>();
    //for(auto ent : filter)
    //  Do things.
}
