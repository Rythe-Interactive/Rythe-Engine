#pragma once
#include <core/core.hpp>

/**
 * @file $safeitemname$.hpp
 */

using namespace legion;

/**@class $safeitemname$
 * @brief Custom system.
 */
class $safeitemname$ final : public System<$safeitemname$>
{
public:
    /**@brief Will automatically be called once at the start of the application.
     */
    virtual void setup();

    /**@brief Default process marked in setup to run as fast as possible on the "Update" interval.
     */
    void update(time::span deltaTime);
};
